package com.teamproject.myweb.command;

public class DebateUploadVO {

}
